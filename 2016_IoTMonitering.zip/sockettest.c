#include <sys/socket.h> //gcc -o sockettest sockettest.c -lwiringPi -I/usr/include/mysql  -L/usr/lib/mysql -lmysqlclient
#include <sys/stat.h>
#include <arpa/inet.h>
#include <wiringPi.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <mysql.h>
#include <signal.h>
#include <termios.h>
#include <sys/signal.h>
#include <time.h>


// SOCKET DEFINE

#define PORT	8088
#define MAXBUF	BUFSIZ /* 클라이언트와 길이를 맞추어준다. */
#define HIGH 1
#define LOW 0
#define VIDEO_ON	14 //카메라 ON
#define VIDEO_OFF	1 //카메라 OFF
#define LEFT		2 //수동제어 왼쪽
#define RIGHT		3 //수동제어 오른쪽
#define AUTO		4 //자동모드로 변환
#define MANUAL		5
#define EXIT		6 //접속종료
#define INTRUSION_DETECTION_MODE  7 
#define SITUATION_DETECTION_MODE  8 
#define PREFERENCESETTING 9 //환경설정
#define GET_COUNT_DATA 10
#define LEFT_STOP 11
#define RIGHT_STOP 12
#define GET_TIMEDATA 13
#define MLEFT 15
#define MLEFT_CENTER 16
#define MCENTER 17
#define MRIGHT_CENTER 18
#define MRIGHT 19


//SQL SET DEFINE

#define DB_HOST "127.0.0.1"
#define DB_USER "root"
#define DB_PASS "mite"
#define DB_NAME "os"
#define CHOP(x) x[strlen(x) - 1] = ' '

int server_sockfd, client_sockfd; 			// 소켓

unsigned baudrate=38400;				//아두이노 시리얼 통신
char *device_list[20]= {
   "/dev/ttyUSB0", "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3", "/dev/ttyS4", "/dev/ttyS5",
   "/dev/ttyS6", "/dev/ttyS7", "/dev/ttyS8", "/dev/ttyS9", "/dev/ttyS10"
};

char sendBuffer[MAXBUF];
int sendSize;
void daySensingOut();
void hourSensingOut();
int open_serial(int key);
int slow_write(int fd, char *buf, int size);
int aduinoSend(char * send);

void intsignal(int sig){
	if(close(server_sockfd) !=0){
		printf("Server Socket Close Error \n");
	}
	if(close(client_sockfd) !=0){
		printf("Client Socket CLose Error \n");
	}
	system("pkill -9 sensingCnt");
	system("pkill -9 anotherFinally");

	printf("Server Terminated :Bye Bye\n");
	exit(0);
}

int main(int argc, char **argv) {
	int choice;
	char buf[MAXBUF];
	char dummy[MAXBUF];
	char file_name[MAXBUF];
	struct sockaddr_in serveraddr, clientaddr;  // 서버와 클라이언트의 소켓 정보
	int client_len;								// 클라이언트 소켓의 바이트 크기
	int chk_bind; 								// 연결 확인 변수
	int read_len;	
	int mode = 9;								// 기본모드는 침입감지 모드
	int count = 0;
	int chk_write;
        int servo_control =0;     //HIGH신호를 한번주기위한 변수
	char *string;
	int n=0;
	
	printf("시작\n");
	fflush(stdout);

	if(wiringPiSetup()==-1){
		return 1;
	}


	client_len = sizeof(clientaddr);


	/* 서버 socket() 생성  */
	server_sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	(void) signal (SIGINT, intsignal);
	if(server_sockfd == -1) {
		perror("socket error : ");
		exit(0);
	}

	printf("소켓 서버가 만들어졌습니다.\n");
	fflush(stdout);

        system("./anotherFinally &");
	system("./sensingCnt&");

	/* bind() */
	bzero(&serveraddr, sizeof(serveraddr)); 	// 해당 메모리 영역 초기화
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
	serveraddr.sin_port = htons(PORT);		// 포트 번호 설정
	chk_bind = bind(server_sockfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));

	if(chk_bind > 0) {
		perror("bind error : ");
		exit(0);
	}

	printf("바인드 작업 완료\n");
	fflush(stdout);	

	/* listen() */

	if(listen(server_sockfd, 5)) {
		perror("listen error : ");
	}


	/* 클라이언트 연결 대기 */

	/* accept() */

	while(1){
		client_sockfd = accept(server_sockfd, (struct sockaddr *)&clientaddr, &client_len);
		printf("New Client Connect: %s\n", inet_ntoa(clientaddr.sin_addr));
		fflush(stdout);

 

		while(1) {
                        
			memset(buf, 0x00, MAXBUF);
			if(read(client_sockfd, buf, MAXBUF) <=0) continue;
			
			//read_len = read(client_sockfd, buf, MAXBUF);	
			//while (read_len < MAXBUF) {
				//read_len += read(client_sockfd, dummy, MAXBUF);
			//}

			choice =atoi(buf);					// 클라이언트가 버퍼에 숫자를 문자로 제공하므로 이의 번호 추출
			printf("buf = %s\n", buf);
			
			
	

			switch(choice) {
				case VIDEO_ON:
					system("/root/GT.sh 2> /dev/null &");
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case VIDEO_OFF:
					system("pkill -9 mjpg_streamer");
					delay(50);
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case LEFT :  //2
					aduinoSend("6");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case RIGHT : //3 
					aduinoSend("7");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case AUTO :
					system("./anotherFinally &");
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case MANUAL :
					system("pkill -9 anotherFinally");
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case INTRUSION_DETECTION_MODE:
					mode = INTRUSION_DETECTION_MODE;
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case SITUATION_DETECTION_MODE:
					mode = SITUATION_DETECTION_MODE;
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;	

				case GET_COUNT_DATA:
					daySensingOut();
					n = write(client_sockfd ,sendBuffer,sendSize+2);
					printf ("나는보냄요");
					fflush(stdout);
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;	

				case LEFT_STOP: //11
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;	

				case RIGHT_STOP: //12
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case GET_TIMEDATA :

					hourSensingOut();

					n = write(client_sockfd ,sendBuffer,sendSize+2);

					printf ("나는보냄요");

					fflush(stdout);

					printf ("Choice = %d\n", choice);

					fflush(stdout);

					break;
			
				case MLEFT :  //15
					aduinoSend("1");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case MLEFT_CENTER :  //16
					aduinoSend("2");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;
			
				case MCENTER :  //17
					aduinoSend("3");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case MRIGHT_CENTER :  //18
					aduinoSend("4");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;

				case MRIGHT :  //19
					aduinoSend("5");
					delay(100);	
					printf ("Choice = %d\n", choice);
					fflush(stdout);
					break;
			

				default :

					printf ("Wrong Choice = %d\n", choice);

				

				} // End Swictch

				if(choice == EXIT){

				 	//system("pkill -9 anotherFinally");

					break;

				}

			} // End While

			printf("새클라이언트 접속을 기다림 ... .... \n");

			fflush(stdout);	

	}//End While

}  //End Main



//일주일 날짜별 데이터 

void daySensingOut(){

	MYSQL       *connection=NULL, conn;

    MYSQL_RES   *sql_result;

    MYSQL_ROW   sql_row;

    int       query_stat; 

 

    char name[12];

    char address[80];

    char tel[12];

    char query[255];

    char out[255];

 

	strcpy(out,"");

    

    mysql_init(&conn);

 

    connection = mysql_real_connect(&conn, DB_HOST,

                                    DB_USER, DB_PASS,

                                    DB_NAME, 3306,

                                    (char *)NULL, 0);

 

    if (connection == NULL)

    {

        fprintf(stderr, "Mysql connection error : %s", mysql_error(&conn));

    }

 

    query_stat = mysql_query(connection, "SELECT sum(sensingCnt), SUBSTRING(curTime,1,10) FROM sensingCnt GROUP BY SUBSTRING(curTime,1,10) DESC LIMIT 7;");

    if (query_stat != 0)

    {

        fprintf(stderr, "Mysql query error : %s", mysql_error(&conn));

    }

    

    sql_result = mysql_store_result(connection);

    

   // printf("%+11s %-30s\n", "cnt", "날짜");

    while ( (sql_row = mysql_fetch_row(sql_result)) != NULL )

    {

        //printf("%+11s %-30s \n", sql_row[0], sql_row[1]);

	strcat(out,sql_row[0]);

	strcat(out,"/");

	strcat(out,sql_row[1]);

	strcat(out,"/");

    }

   strcpy(sendBuffer,out);

   strcat(sendBuffer,"\n");

   sendSize = strlen(out);



  //printf("%s\n",out);

//printf("%s\n",sendBuffer);

   

    mysql_free_result(sql_result);

    mysql_close(connection);

 

}//END DAY SENSING





//일주일 시간별 데이터

void hourSensingOut(){

	MYSQL       *connection=NULL, conn;

    MYSQL_RES   *sql_result;

    MYSQL_ROW   sql_row;

    int       query_stat; 

 

    char name[12];

    char address[80];

    char tel[12];

    char query[255];

    char out[500];

 

	strcpy(out,"");

    

    mysql_init(&conn);

 

    connection = mysql_real_connect(&conn, DB_HOST,

                                    DB_USER, DB_PASS,

                                    DB_NAME, 3306,

                                    (char *)NULL, 0);

 

    if (connection == NULL)

    {

        fprintf(stderr, "Mysql connection error : %s", mysql_error(&conn));

    }



	query_stat = mysql_query(connection, "SELECT COUNT(SUBSTRING(curTime,1,10)) FROM sensingCnt GROUP BY SUBSTRING(curTime,1,10) DESC LIMIT 1");

    if (query_stat != 0)

    {

        fprintf(stderr, "Mysql query error : %s", mysql_error(&conn));

    }

    

    sql_result = mysql_store_result(connection);

    

   // printf("%+11s %-30s\n", "cnt", "날짜");

    while ( (sql_row = mysql_fetch_row(sql_result)) != NULL )

    {

        //printf("%+11s %-30s \n", sql_row[0], sql_row[1]);

	strcat(out,sql_row[0]);

	strcat(out,"/");

    }

 

    query_stat = mysql_query(connection, "SELECT sensingCnt,  SUBSTRING(curTime,1,13) FROM sensingCnt ORDER BY curTime DESC LIMIT 21;");

    if (query_stat != 0)

    {

        fprintf(stderr, "Mysql query error : %s", mysql_error(&conn));

    }

    

    sql_result = mysql_store_result(connection);

    

   // printf("%+11s %-30s\n", "cnt", "날짜");

    while ( (sql_row = mysql_fetch_row(sql_result)) != NULL )

    {

        //printf("%+11s %-30s \n", sql_row[0], sql_row[1]);

	strcat(out,sql_row[0]);

	strcat(out,"/");

	strcat(out,sql_row[1]);

	strcat(out,"/");

    }



	printf("%s\n",out);



	strcpy(sendBuffer,out);

   strcat(sendBuffer,"\n");

   sendSize = strlen(out);

 

    mysql_free_result(sql_result);

    mysql_close(connection);



}



int open_serial(int key) {

	int fd;

    	struct termios oldtio, newtio;

	

	fd = open(device_list[key], O_RDWR | O_NOCTTY );

	if (fd <0) {

          printf("Serial %d  Device Open Error\n", key );

          exit(1);

	}

	

    	bzero(&newtio, sizeof(newtio));

	newtio.c_cflag = baudrate | CS8 | CLOCAL | CREAD;

	newtio.c_iflag = IGNPAR;

	newtio.c_oflag = 0;

	newtio.c_lflag = 0;

	newtio.c_cc[VTIME] = 0;   		// inter-character timer unused

	newtio.c_cc[VMIN] = 1;    		// blocking read until 8 chars received

	

	tcflush(fd, TCIFLUSH);

	tcsetattr(fd,TCSANOW,&newtio);

	

	return fd;

}





int slow_write(int fd, char *buf, int size) {

   int i, n;

   char str[2];

   for (i=0; i<size; i++) {

      if (buf[i]=='\0') return i;

      str[0]=buf[i]; str[1]=0;

      n= write(fd, str, 1);

      if (n!=1) {

	  printf("Write error found\n");

          exit(-1);

      }

      usleep(1);

   }

   return size;

}



int aduinoSend(char * send) {

	int n, i, key=0;

	int fd_port;				// 송신 시리얼 장치 식별번호



	fd_port = open_serial(key);		// 송신포트 open

	printf("\n\n");



	 n=slow_write(fd_port, send,1);	// \n LF \r CR 



	close(fd_port);

	return 0;

}
















