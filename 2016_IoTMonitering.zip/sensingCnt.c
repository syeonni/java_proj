#include <mysql.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h> // gcc  sensingCnt.c -o sensingCnt -lpthread -I/usr/include/mysql  -L/usr/lib/mysql -lmysqlclient -lwiringPi
#include <time.h>
#include <wiringPi.h>
#define SW1 23
#define SW2 24
#define SW3 25
struct tm *t;
time_t timer;
long daySec;
long sensingCnt=0;
#define DB_HOST "127.0.0.1"
#define DB_USER "root"
#define DB_PASS "mite"
#define DB_NAME "os"
#define CHOP(x) x[strlen(x) - 1] = ' '
MYSQL       *connection=NULL, conn;
MYSQL_RES   *sql_result;
MYSQL_ROW   sql_row;
int       query_stat;
char query[255];

int gcmEnable = 0;
int timeCount=0;
 
char * ltoa (long val, char *buf, unsigned radix)
 {
     char *p;            /* pointer to traverse string */
     char *firstdig;        /* pointer to first digit */ 
     char temp;            /* temp char */ 
     unsigned digval;    /* value of digit */
    p = buf;
    if (radix == 10 && val < 0) { /* negative, so output '-' and negate */
         *p++ = '-';
         val = (unsigned long)(-(long)val);
     }
    firstdig = p;    /* save pointer to first digit */
    do {
         digval = (unsigned) (val % radix);
         val /= radix; /* get next digit */
        /* convert to ascii and store */
         if (digval > 9)
             *p++ = (char) (digval - 10 + 'a');    /* a letter */
         else
             *p++ = (char) (digval + '0');        /* a digit */
     } while (val > 0);
    /* We now have the digit of the number in the buffer, but in reverse order. Thus we reverse them now. */
    *p-- = '\0';    /* terminate string; p points to last digit */
    do {
         temp = *p;
         *p = *firstdig;
         *firstdig = temp; /* swap *p and *firstdig */
         --p;
         ++firstdig; /* advance to next two digits */
         } while (firstdig < p); /* repeat until halfway */
    return buf;
 }
 
void* My(void* Para)
{
   while(1)
   {
         char a[10];
 	struct tm *t;
 	time_t timer;
 	int tempDate[6];
 	char saveDate[20];
 	timer = time(NULL);
   	 t = localtime(&timer);
	
	ltoa(t->tm_year+1900,saveDate,10); strcat(saveDate, "-");
 	strcat(saveDate, ltoa(t->tm_mon+1,a,10)); strcat(saveDate, "-");
 	strcat(saveDate, ltoa(t->tm_mday,a,10)); strcat(saveDate, " ");
 	strcat(saveDate, ltoa(t->tm_hour,a,10)); strcat(saveDate, ":");
 	strcat(saveDate, ltoa(t->tm_min,a,10)); strcat(saveDate, ":");
 	strcat(saveDate, ltoa(t->tm_sec,a,10));
 	//printf("%s\n",saveDate);
 
        daySec = t->tm_hour*3600 + t->tm_min*60 + t->tm_sec;
        //printf("오늘의 시간(초) %d\n",daySec);
	fflush(stdout);
 
        if(daySec == 32400 || daySec == 46800 || daySec == 68400){       //아침 9시 32400 점심 1시 46800 저녁 7시 68400
          mysql_init(&conn);
          connection = mysql_real_connect(&conn, DB_HOST,
                                    DB_USER, DB_PASS,
                                    DB_NAME, 3306,
                                    (char *)NULL, 0);
          if (connection == NULL)
          {
            fprintf(stderr, "Mysql connection error : %s", mysql_error(&conn));
          }
          sprintf(query, "insert into sensingCnt values "
                   "('%d', '%s')",
                   sensingCnt, saveDate);
          query_stat = mysql_query(connection, query);
          if (query_stat != 0){
          	fprintf(stderr, "Mysql query error : %s", mysql_error(&conn));
          }
          mysql_close(connection);
          sensingCnt=0;
        }
        sleep(1);
   }
}
 
int main(int argc, char **argv)
{
	int i; 
	pthread_t re;
	int a;
	void* s;
	a = pthread_create(&re,NULL,My,NULL);
   
	//printf("%s\n",s);
	fflush(stdout);
 
	if(wiringPiSetup() == -1)
		return 1;
	pinMode(SW1, INPUT);
	pinMode(SW2, INPUT);
	pinMode(SW3, INPUT);
	for(i=0;;i++){
		if(digitalRead(SW1) == 1 || digitalRead(SW2) == 1 || digitalRead(SW3) == 1){
			sensingCnt++;
			
			fflush(stdout);
			timeCount = 0;
			if(gcmEnable == 0){
		  		gcmEnable = 1;
				printf("보낸\n");
		  		system("./postc &");
			}
		 }
		delay(1000);
		timeCount++;
		if(timeCount==3000){
			timeCount=0;
			gcmEnable = 0;
		}
	}
	return 0;
}
