#include <stdio.h>
#include <wiringPi.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h> // gcc  test.c -o test -lpthread


#define SW1 23
#define SW2 24
#define SW3 25


int site1Count = 0;
int site2Count = 0;
int site3Count = 0;
int site4Count = 0;
int site5Count = 0;;

int main(int argc, char **argv){
    	int i;
    
	if(wiringPiSetup() == -1)
		return 1;

	pinMode(SW1, INPUT);
	pinMode(SW2, INPUT);
	pinMode(SW3, INPUT);
	

	for(i=0;;i++){
		
		 /*if(digitalRead(SW1) == 1 &&digitalRead(SW3) == 1 &&digitalRead(SW2) == 0){
	       		site4Count++;
		}
		else if(digitalRead(SW2) == 1 &&digitalRead(SW3) == 1 &&digitalRead(SW1) == 0){
		 	 site5Count++;
			
		}   
		else if(digitalRead(SW1) == 1 &&digitalRead(SW3) == 0 &&digitalRead(SW2) == 0){
	       		site1Count++;
		}
		else if(digitalRead(SW2) == 1 &&digitalRead(SW3) == 0 &&digitalRead(SW1) == 0) {
		 	 site2Count++;
			
		}   
		else if(digitalRead(SW3) == 1 &&digitalRead(SW2) == 0 &&digitalRead(SW1) == 0){
		 	site3Count++; 
		  	
	       }*/
/*
		if(digitalRead(SW1) == 1 && digitalRead(SW2) == 1 && digitalRead(SW3) == 1){
		}
		
		else if(digitalRead(SW1) == 1 && digitalRead(SW2) == 0){
			if(digitalRead(SW3) == 1)
				site4Count++;
			else
	       			site1Count++;
		}
		else if(digitalRead(SW2) == 1 && digitalRead(SW1) == 0) {
			if(digitalRead(SW3) == 1)
				site5Count++;
			else
		 	 	site2Count++;			
		}   
		else if(digitalRead(SW3) == 1){
			if(digitalRead(SW1) == 1 && digitalRead(SW2) == 0)
				site4Count++;
			else if(digitalRead(SW2) == 1 && digitalRead(SW1) == 0)
				site5Count++;
			else if(digitalRead(SW1) == 0 && digitalRead(SW2) == 0)
		 		site3Count++; 	
	       }
*/
		if(digitalRead(SW1) == 1 && digitalRead(SW2) == 1 && digitalRead(SW3) == 1){
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		}
		else if(digitalRead(SW1) == 1 && digitalRead(SW2) == 1) {
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		}
		else if(digitalRead(SW1) == 1) {
			if (digitalRead(SW3) == 1)
				site4Count++;
			else
	       			site1Count++;
		}
		else if(digitalRead(SW2) == 1) {
			if (digitalRead(SW3) == 1)
				site5Count++;
			else
	       			site2Count++;
		}
		else if(digitalRead(SW3) == 1) {
       			site3Count++;
		}

		if(site4Count == 3){
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		      system("./find_sender 2 &");
			printf("왼중\n");
		      delay(1900);
		}
		else if(site5Count == 3){
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		      system("./find_sender 4 &");
			printf("오중\n");
		      delay(1900);
		}

	  	else if(site1Count == 3){
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		      system("./find_sender 1 &");
			printf("왼\n");
		      delay(1900);
		}
		else if(site2Count ==3){
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		      system("./find_sender 5 &");
			printf("오\n");
		      delay(1900);
		}
		else if(site3Count == 3){
		      site1Count = 0;
		      site2Count = 0;
		      site3Count = 0;
			site4Count = 0;
		      site5Count = 0;
		      system("./find_sender 3 &");
			printf("중\n");
		      delay(1900);
		}
		

	 	delay(100);

	}
   
	return 0;
}
