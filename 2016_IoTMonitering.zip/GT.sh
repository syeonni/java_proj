export STREAMER_PATH=/root/GT/mjpg-streamer/mjpg-streamer-experimental
export LD_LIBRARY_PATH=$STREAMER_PATH
$STREAMER_PATH/mjpg_streamer -i "input_raspicam.so -x 1080  -y 460 -fps 20  -vs -quality 100" -o "output_http.so -w $STREAMER_PATH/www -p 8081" &
