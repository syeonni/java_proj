//
//	320보드의 시리얼 포트 중 어떤 장치가 현재 출력을 위해 사용되고 있는지를 파악하기 위한 유틸리티
//      baud rate와 포트를 찾기 위해 해당되는 조합을 넣고 실행해 봄
//	장치가 제대로 인식되면 그 터미널을 통해 "abc\n\r" 이라는 문자열들이 출력될 것임
//

#include <stdlib.h>
#include <termios.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/signal.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>

unsigned baudrate=38400;

char *device_list[20]= {
   "/dev/ttyUSB0", "/dev/ttyS1", "/dev/ttyS2", "/dev/ttyS3", "/dev/ttyS4", "/dev/ttyS5",
   "/dev/ttyS6", "/dev/ttyS7", "/dev/ttyS8", "/dev/ttyS9", "/dev/ttyS10"
};


int open_serial(int key) {
	int fd;
    	struct termios oldtio, newtio;
	
	fd = open(device_list[key], O_RDWR | O_NOCTTY );
	if (fd <0) {
          printf("Serial %d  Device Open Error\n", key );
          exit(1);
	}
	
    	bzero(&newtio, sizeof(newtio));
	newtio.c_cflag = baudrate | CS8 | CLOCAL | CREAD;
	newtio.c_iflag = IGNPAR;
	newtio.c_oflag = 0;
	newtio.c_lflag = 0;
	newtio.c_cc[VTIME] = 0;   		// inter-character timer unused
	newtio.c_cc[VMIN] = 1;    		// blocking read until 8 chars received
	
	tcflush(fd, TCIFLUSH);
	tcsetattr(fd,TCSANOW,&newtio);
	
	return fd;
}


int slow_write(int fd, char *buf, int size) {
   int i, n;
   char str[2];
   for (i=0; i<size; i++) {
      if (buf[i]=='\0') return i;
      str[0]=buf[i]; str[1]=0;
      n= write(fd, str, 1);
      if (n!=1) {
	  printf("Write error found\n");
          exit(-1);
      }
      usleep(1);
   }
   return size;
}
int main(int argc, char * argv[]) {
	int n, i, key=0;
	int fd_port;				// 송신 시리얼 장치 식별번호

	fd_port = open_serial(key);		// 송신포트 open
	printf("\n\n");

	 n=slow_write(fd_port, argv[1],1);	// \n LF \r CR 

	close(fd_port);
	return 0;
}


